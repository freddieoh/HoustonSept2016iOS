//
//  ViewController.h
//  StepperView
//
//  Created by Fredrick Ohen on 10/6/16.
//  Copyright © 2016 GeeCode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StepperView.h"
@interface ViewController : UIViewController<StepperViewDelegate>


@end

